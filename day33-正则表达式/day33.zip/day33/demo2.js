// 常用正则
//邮箱
var reg =/^[\w-]+(\.[\w-]+)*@[\w-]+(\.[\w-]+)+$/;
console.log(reg.test("390351113@qqcom"));


