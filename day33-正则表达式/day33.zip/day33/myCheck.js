//优化代码。实现代码可复用！！！！！
		//(1)不断复用getById(id名)，避免一直在用document.getEle.....
		var getById=function(id){
			return document.getElementById(id);
		}
		//比如找：名字
		//console.log(getById("uname"))
		//比如找：密码
		//console.log(getById("pwd"))
		
		//(2)优化DOM提示操作：
		console.log(getById("pwd").nextElementSibling.innerHTML)
		function setMsg(id,txt){
			getById(id).nextElementSibling.innerHTML =txt; 
		}
		//使用
		//setMsg("phone","您的手机不合法");
		//(3)优化验证方法
		var myFormCheck =function(id,fn){
			getById(id).onblur=fn;
		}
		/***以上代码可以另存为一个js工具文件，直接被复用**/