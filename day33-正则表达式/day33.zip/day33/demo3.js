// 字符串中使用正则表达式

//匹配 match(正则)    /规则/匹配模式  i表示忽略大小写，g表示全局匹配！
var str= "this is html,I love Html";
console.log(str.match(/html/ig));
//字符串.replace(正则,"新内容")  替换
console.log(str.replace(/html/ig,"css"));
//查找   str.search()
var str= "今天aa周四,周四离周末还有1天";
console.log(str.search(/周四/));// 返回第一次出现的位置！
//分割 str.split()   
var str = "a b c d e f";
console.log(str.split(/ /).length);
//去掉字符串前后空格     /^\s+|\s+$/g
var str ="     hello ";
console.log(str.replace(/^\s+|\s+$/g,'').length)




