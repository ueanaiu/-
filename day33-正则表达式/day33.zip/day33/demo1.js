// 01邮箱验证
console.log("验证邮箱");

console.log(/^\w+@\w+(\.[a-zA-Z]{2,3}){1,2}$/.test("390351113qq.com"));

//02 正则定义：实现验证java单词是否存在   匹配模式：i表示忽略大小写
var reg = /JAVA/i;
console.log(reg.test("javaScript"));

//03 定义正则标准语法：  new RegExp("规则"，“匹配模式”)
var reg = new RegExp("java","i");
console.log(reg.test("ECMAScript"));

//04 exec() 实现验证: 返回数组， 找不到返回null
console.log(/java/.exec("12EsssScript"));


// 第二节：规则字符串
// 1  /^规则 $/  匹配头和尾
console.log(/^java/.test('ajavaScript'));  //false
console.log(/java$/.test('javaScriptjava')); //true

//2 1个空白字符 \s  非空白 \S
console.log(/\s/.test(" ")); //true
console.log(/a\s/.test("a1")); //false
console.log(/html\S/.test("html "));
// 3 \d表示0-9的数字 等价于 [0-9]，   \D表示非数字 等价于  [^0-9]
console.log(/\d/.test("0")); //true
console.log(/[0-9]/.test("0")); //true   []表示范围

console.log(/\D/.test("A")); //true
console.log(/[^0-9]/.test("A")); //true
// 4 []表示范围 比如：[0-9]表示0到9的数字   [a-z]表示小写a到z中的一个！ [^ ]表示非
console.log(/[a-z]/.test("b")); //true

//5 \w:字母数字或下划线 等价于[A-Za-z0-9_]  \W非字母数字或下划线： [^a-zA-Z0-9_]
console.log(/a\w/.test("a%"));  //false
console.log(/a[a-zA-Z0-9_]/.test("a_"));  //true
console.log(/a\W/.test("a%"));  //true

//6 非换行以外的任意字符   .
console.log(/b.g/.test("big"));
console.log(/b.g/.test("b\ng")); //  \n表示换行

//7 ^&.{}[]等符号在正则中有特殊含义， 一旦出现在待校验的字符串中， 写规则时使用 "转义符号\"变为普通的字符
console.log(/\$hi/.test("$hi"));

//8  ()表示一组   
//  {n}:匹配前一项目n次--->对应0次或n次
console.log("重复n次："+/a{2}/.test("aaa"));
// {n,}:重复前一项至少n次 -->至少n次
console.log("重复至少2次："+/b{2,}/.test("bbbbbbbbbb"));
// {n,m}:重复前一项至少n次,不能高于m次   ---大于等于n小于等于m  失败！！！  漏洞！！！用*或+代替
console.log("重复2-4次："+/b{2,4}/.test("bbbbbbbbbbbbb"));


//手机号验证前2位
console.log("验证前2位："+/1[3|5|7|8]/.test(15));
// 1[3或5或7或8] 0-9数字
console.log("验证前3位："+/1[3|5|7|8]\d/.test("159"));
console.log("验证前3位："+/1[3|5|7|8][0-9]/.test("159"));
// 1 [3或5或7或8] 0-9数字 [重复前1项n次]  正好11位   {9}包括前一个共9次！
console.log("验证11位："+/^1[3|5|7|8][0-9]{9}$/.test("17600950805"));


//*==》匹配前一项0次或多次   +：1次或多次，包括前1个   ?:0或1次
console.log(/a*/.test("aaaaaaaaaaaaaaaaaaaaaa"));
console.log(/a+/.test(""));

console.log(/a?/.test("aaaaa")); //等价于{n,m} 无法使用

// 常用正则测试
//1 正整数
console.log(/^-?\d+$/.test("12"));































